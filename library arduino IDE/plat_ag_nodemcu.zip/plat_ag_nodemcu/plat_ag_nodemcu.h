#ifndef PLAT_AG_NODEMCU_H
#define PLAT_AG_NODEMCU_H

#include <Arduino.h>

/*fungsi untuk baca data dari perangkat*/
String readData(String server, String key, String ch, float val);

/*fungsi untuk kirim data ke perangkat*/
int writeData(String server, String key, String ch);

#endif
