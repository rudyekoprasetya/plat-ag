#include "plat_ag.h"

#include <Arduino_JSON.h>
#include <HTTPClient.h>

/*fungsi untuk baca data dari perangkat*/
String readData(String server, String key, String ch, float val) {
  HTTPClient http;
  String serverPath = server + "api/read?api_key=" + key + "&ch=" +ch+ "&val=" +val;
  http.begin(serverPath);
  int httpResponseCode = http.GET();
  String payload = "{}"; 
  if (httpResponseCode>0) {
    Serial.print("HTTP Response code: ");
    Serial.println(httpResponseCode);
    payload = http.getString();
  }
  else {
    Serial.print("Error code: ");
    Serial.println(httpResponseCode);
  }
  http.end();

  return payload;
}

/*fungsi untuk kirim data ke perangkat*/
int writeData(String server,String key, String ch) {
  HTTPClient http;
  String serverPath = server + "api/getread?api_key=" + key + "&ch=" +ch;
  http.begin(serverPath);
  int httpResponseCode = http.GET();
  String payload = "{}"; 
  if (httpResponseCode>0) {
    Serial.print("HTTP Response code: ");
    Serial.println(httpResponseCode);
    payload = http.getString();
  }
  else {
    Serial.print("Error code: ");
    Serial.println(httpResponseCode);
  }
  http.end();

  JSONVar myObject = JSON.parse(payload);

  if (JSON.typeof(myObject) == "undefined") {
    Serial.println("Parsing input failed!");
  }
  Serial.println(myObject);

  JSONVar keys = myObject.keys();
  JSONVar value = myObject[keys[1]];

  return value;
}
